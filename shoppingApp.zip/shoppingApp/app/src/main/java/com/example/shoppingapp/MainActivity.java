package com.example.shoppingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

Spinner product;
TextView price,gtotal,bill;
ImageView photo;
Button addButton;
RadioButton pickup,delivery;
ArrayList<products>List=new ArrayList<>();
ArrayList<String>Names=new ArrayList<>();
Double total = 0.0;
Double holdRate = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        product=findViewById(R.id.spProducts);
        price=findViewById(R.id.tvPrice);
        photo=findViewById(R.id.ivPhoto);
        gtotal=findViewById(R.id.tvTotal);
        addButton=findViewById(R.id.btAdd);
        pickup=findViewById(R.id.rbtPickup);
        delivery=findViewById(R.id.rbtnDelivery);
        bill=findViewById(R.id.tvBill);
        fillData();


        ArrayAdapter AA = new ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,Names);
        product.setAdapter(AA);

        product.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                price.setText(String.valueOf(List.get(position).getRate()));
                holdRate = List.get(position).getRate();
                photo.setImageResource(List.get(position).getImage());
            }
              @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

       });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                total+=holdRate;
                gtotal.setText(String.valueOf(total));
            }
        });

        pickup.setOnClickListener(new ButtonEvents());
        delivery.setOnClickListener(new ButtonEvents());

        }
    private class ButtonEvents implements View.OnClickListener{


        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.rbtPickup:
                    bill.setText(String.valueOf(total));
                    break;
                case R.id.rbtnDelivery:
                    if (total>100)
                    bill.setText(String.valueOf(total+(total*0.10)));
                    else
                        bill.setText(String.valueOf(total));
                    break;

            }

        }
    }

         public void fillData(){
        List.add(new products("biscuits",25.0,R.drawable.biscuits));
             List.add(new products("chocolate",30.0,R.drawable.chocolate));
             List.add(new products("colors",50.0,R.drawable.colors));
             List.add(new products("pens",20.0,R.drawable.pens));

             for(products cr:List)
                 Names.add(cr.getName());

         }



}