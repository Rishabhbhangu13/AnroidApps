package com.example.shoppingapp;

public class products {

private String name;
private Double rate;
private int  image;

public products(String name,Double rate,int image){
   this.image = image;
   this.name = name;
   this.rate = rate;
}

    public Double getRate() {
        return rate;
    }

    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }
}
